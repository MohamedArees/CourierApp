IF OBJECT_ID(Route) IS NOT NULL
DROP TABLE Route
GO

Create table Route
(
	[Address] varchar(200),
	[Phone] numeric(10) not null,
	[LandmarkId] Tinyint constraint pk_LandmarkId Primary key Identity,
	[LandmarkName] varchar(200) not null,
	[Latitude] numeric not null,
	[Longitude] numeric not null,
	[PointOrder] Tinyint not null,
	[Distance] numeric not null,
	[Created] Date DEFAULT GETDATE()
)
Go
